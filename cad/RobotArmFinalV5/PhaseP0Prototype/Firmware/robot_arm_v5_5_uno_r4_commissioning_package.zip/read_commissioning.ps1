param(
    [string]$Port = "COM3",
    [int]$Seconds = 10
)

$ErrorActionPreference = "Stop"
$serial = New-Object System.IO.Ports.SerialPort `
    $Port,115200,None,8,One
$serial.ReadTimeout = 500
$serial.NewLine = "`n"
$serial.Open()

try {
    $deadline = (Get-Date).AddSeconds($Seconds)
    while ((Get-Date) -lt $deadline) {
        try {
            $line = $serial.ReadLine()
            Write-Host $line.Trim()
        } catch [System.TimeoutException] {
        }
    }
} finally {
    $serial.Close()
}
