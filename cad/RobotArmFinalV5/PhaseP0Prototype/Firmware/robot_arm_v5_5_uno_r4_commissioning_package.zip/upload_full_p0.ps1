function Get-ArduinoCli {
    $candidate = Join-Path $env:LOCALAPPDATA `
        "Programs\Arduino IDE\resources\app\lib\backend\resources\arduino-cli.exe"
    if (-not (Test-Path $candidate)) {
        throw "Arduino IDE bundled arduino-cli was not found."
    }
    return $candidate
}

function Get-UnoPorts {
    param([string]$Cli)
    $text = & $Cli board list 2>&1 | Out-String
    $ports = @()
    foreach ($line in ($text -split "`r?`n")) {
        if ($line -match '^(COM\d+)\s+.*UNO R4') {
            $ports += $Matches[1]
        }
    }
    return $ports | Select-Object -Unique
}

function Test-SerialPortOpen {
    param([string]$Port)
    try {
        $serial = New-Object System.IO.Ports.SerialPort `
            $Port,115200,None,8,One
        $serial.ReadTimeout = 300
        $serial.Open()
        $serial.Close()
        return $true
    } catch {
        return $false
    }
}

function Wait-UnoPort {
    param(
        [string]$Cli,
        [int]$Seconds = 30
    )
    $deadline = (Get-Date).AddSeconds($Seconds)
    while ((Get-Date) -lt $deadline) {
        foreach ($port in (Get-UnoPorts -Cli $Cli)) {
            if (Test-SerialPortOpen -Port $port) {
                return $port
            }
        }

        $all = Get-CimInstance Win32_SerialPort -ErrorAction SilentlyContinue |
            Select-Object -ExpandProperty DeviceID
        foreach ($port in $all) {
            if (
                $port -ne "COM1" -and
                (Test-SerialPortOpen -Port $port)
            ) {
                return $port
            }
        }
        Start-Sleep -Milliseconds 300
    }
    return $null
}

function Compile-Sketch {
    param(
        [string]$Cli,
        [string]$Sketch,
        [string]$Build
    )
    New-Item -ItemType Directory -Force -Path $Build | Out-Null
    & $Cli compile `
        --fqbn arduino:renesas_uno:unor4wifi `
        --output-dir $Build `
        $Sketch
    if ($LASTEXITCODE -ne 0) {
        throw "Compilation failed."
    }
}

function Upload-Build {
    param(
        [string]$Cli,
        [string]$Port,
        [string]$Build
    )
    & $Cli upload `
        -p $Port `
        --fqbn arduino:renesas_uno:unor4wifi `
        --input-dir $Build
    if ($LASTEXITCODE -ne 0) {
        throw "Upload failed on $Port."
    }
}

param(
    [switch]$ServoPowerPhysicallyDisconnected
)

$ErrorActionPreference = "Stop"
if (-not $ServoPowerPhysicallyDisconnected) {
    throw @"
Refusing to upload the PWM firmware.
Disconnect the external 6 V servo power rail, then run:

.\upload_full_p0.ps1 -ServoPowerPhysicallyDisconnected
"@
}

$root = $PSScriptRoot
$cli = Get-ArduinoCli
$sketch = Join-Path $root "robot_arm_p0_uno_r4"
$build = Join-Path $root "full_build"

& $cli lib install "ArduinoJson@7.4.2"
if ($LASTEXITCODE -ne 0) {
    throw "ArduinoJson installation failed."
}
& $cli lib install "Servo"
if ($LASTEXITCODE -ne 0) {
    throw "Servo library installation failed."
}

Compile-Sketch -Cli $cli -Sketch $sketch -Build $build

$port = Wait-UnoPort -Cli $cli -Seconds 5
if (-not $port) {
    Write-Host "Double-press RESET on the UNO R4 WiFi now."
    $port = Wait-UnoPort -Cli $cli -Seconds 30
}
if (-not $port) {
    throw "No usable UNO R4 or bootloader serial port was found."
}

Upload-Build -Cli $cli -Port $port -Build $build
Write-Host "Full P0 firmware uploaded on $port."
Write-Host "Keep external servo power disconnected until NC inputs are verified."
